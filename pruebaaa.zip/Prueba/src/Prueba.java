
public class Prueba {
	String k ="fafaf";
}
